#include<iostream>
#include<vector>
#include<cstdlib>
#include<stdbool.h>
#include<string>
#include<stack>

#define str(x) #x

using std::vector;
using std::cout;
using std::stack;



enum Faces
{
   Nine = 9, Ten = 10, Jack = 11, Queen = 12, King = 13, Ace = 14
};

enum Suits
{
    Daimonds , Clubs, Hearts, Spades
};

struct Card
{
    Suits suit;
    Faces face;       

};

struct Deck
{
    vector<Card> d {};     
};

void shuffleDeck(Deck& deck)
{
    Deck newShuffle;
    Card tempCard;
    while (!deck.d.empty())
    {
        size_t r = rand()%deck.d.size();
        tempCard = deck.d[r];
        newShuffle.d.push_back(tempCard);
    }

    deck = newShuffle;
    
};

void createDeck(Deck& deck)
{
    for (size_t i = 0; i < sizeof(Suits); i++)
    {
        for (size_t f = 0; i < sizeof(Faces); f++)
        {
            Card newCard;
            newCard.face = Faces(f);
            newCard.suit = Suits(i);
            deck.d.push_back(newCard);
        }
        
    }
    
};

struct Player
{    
    bool isWinner=false;
    vector<Card> hand {};
};

struct Team
{    
    Player player1;
    Player player2;

    void createTeam(Player player_1, Player player_2)
    {
        Player player1 = player_1;
        Player player2 = player_2;
    }
}; 

void dealCards(Deck& deck, Team team1, Team team2)
{
    while (!team2.player2.hand.size() == 4)
    {
        for (size_t i = 0; i < deck.d.size(); i++)
        {
            team1.player1.hand.push_back(deck.d[i]);
            team1.player2.hand.push_back(deck.d[i+1]);
            team2.player1.hand.push_back(deck.d[i+2]);
            team2.player2.hand.push_back(deck.d[i+3]);
        }
    }
};

struct Game 
{
    Suits trump; 
    bool winner = false;
    stack<Card> table;
    
    vector<Player> winners {};  
    Deck gameDeck;

        Player player1;
        Player player2;
        Player player3;
        Player player4;

        Team team1;
        Team team2;

        void setTrump(Deck deck) { trump = deck.d[1].suit; };
};



void createGame(Game game)
{
    game.team1.createTeam(game.player1, game.player2);
    game.team2.createTeam(game.player3, game.player4);
        
    createDeck(game.gameDeck);
    shuffleDeck(game.gameDeck);
    dealCards(game.gameDeck, game.team1, game.team2);

    game.setTrump(game.gameDeck);
};

void game(Game& g)
{
    createGame(g);

        for (size_t i = 0; i < 100; i++)
        {
            g.player1.isWinner=false;
            g.player2.isWinner=false;
            g.player3.isWinner=false;
            g.player4.isWinner=false;

            g.setTrump(g.gameDeck);            
            
           
            playHand(g.player1, g);
            playHand(g.player2, g);
            playHand(g.player3, g);
            playHand(g.player4, g);
            
            for (size_t i = 0; i < g.table.size(); i++)
            {
                
            }
                
        } 
};


void playHand(Player& player, Game& game)
{
    for (size_t i = 0; i < player.hand.size(); i++)
    {
        if (player.hand[i].suit == game.trump && player.hand[i].face == Jack)
        {
            player.isWinner;  
            
        }
        else if (player.hand[i].suit == game.trump)
        {
            if (player.hand[i].face <= Ace)
            {
                game.table.push(player.hand[i]);            
            }            
        }
        else if (player.hand[i].face > game.trump)
        {
            if (player.hand[i].face <= Ace)
            {
                game.table.push(player.hand[i]);            
            }   
        }       
        else{ game.table.push(player.hand[i]); }
    }
};







int main()
{
    Game Euchre;  
    game(Euchre);
    
    return 0;
}